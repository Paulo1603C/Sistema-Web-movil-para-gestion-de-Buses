﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidad
{
    public class FrecuenciaParadaEntidad
    {
        public int? Id { get; set; }

        public int? IdFrecuencia { get; set; }
        public string? Frecuencia { get; set; }

        public int? IdLugar { get; set; }
        public string? Lugar { get; set; }

        public int? Orden { get; set; }

    }
}
