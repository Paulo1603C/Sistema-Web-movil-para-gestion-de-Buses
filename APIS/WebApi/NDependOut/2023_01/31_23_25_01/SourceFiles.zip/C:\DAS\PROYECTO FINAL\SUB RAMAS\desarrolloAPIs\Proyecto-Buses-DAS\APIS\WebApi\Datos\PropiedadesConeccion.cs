﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public static class PropiedadesConeccion
    {
        public static string cadenaConexion = "Data Source=MovilmitogBuses.mssql.somee.com;Initial Catalog=MovilmitogBuses;Persist Security Info=False;User ID=DIEGOT_SQLLogin_1;Password=a7yml197en;TrustServerCertificate=True";
    }
}
